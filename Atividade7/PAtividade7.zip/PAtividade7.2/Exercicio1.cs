﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7._2
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspaçosEmBranco_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char branco in rchtTxt.Text)
            {
                if (Char.IsWhiteSpace(branco))
                {
                    contador += 1;
                }
            }
            MessageBox.Show("O texto tem " + contador.ToString() +
                "  caracteres em branco");
        }

        private void btnQuanidadeR_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int letraR = 0;
            string caixa = rchtTxt.Text.Trim();
            int tamanho = caixa.Length;
            while (contador < tamanho)
            {
                if (Char.ToUpper(caixa[contador]) == 'R')
                {
                    letraR += 1;
                }
                contador += 1;
            }
            MessageBox.Show("Na caixa de texto contém " +
                letraR.ToString() + " letras R");

        }

        private void btnParDeLetras_Click(object sender, EventArgs e)
        {
            int contador = 0;
            double parDeLetras = 0; 
            string frase = rchtTxt.Text.Trim();
            int tamanho = frase.Length;
            for (contador=0; contador < tamanho; contador ++)
            {
                if ((frase[contador] == 's') || (frase[contador] == 's') ||
             (frase[contador] == 's') || (frase[contador] == 'R'))
             {
           parDeLetras += 0.5;
            }
            }
            MessageBox.Show("Na frase tem " + parDeLetras.ToString() + " par de letras");


        }
    }
}
