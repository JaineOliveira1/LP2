﻿
namespace PAtividade7._2
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnParDeLetras = new System.Windows.Forms.Button();
            this.btnQuanidadeR = new System.Windows.Forms.Button();
            this.btnEspaçosEmBranco = new System.Windows.Forms.Button();
            this.rchtTxt = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnParDeLetras
            // 
            this.btnParDeLetras.Location = new System.Drawing.Point(416, 214);
            this.btnParDeLetras.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnParDeLetras.Name = "btnParDeLetras";
            this.btnParDeLetras.Size = new System.Drawing.Size(111, 89);
            this.btnParDeLetras.TabIndex = 9;
            this.btnParDeLetras.Text = "Contar par de letras";
            this.btnParDeLetras.UseVisualStyleBackColor = true;
            this.btnParDeLetras.Click += new System.EventHandler(this.btnParDeLetras_Click);
            // 
            // btnQuanidadeR
            // 
            this.btnQuanidadeR.Location = new System.Drawing.Point(267, 214);
            this.btnQuanidadeR.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnQuanidadeR.Name = "btnQuanidadeR";
            this.btnQuanidadeR.Size = new System.Drawing.Size(116, 89);
            this.btnQuanidadeR.TabIndex = 8;
            this.btnQuanidadeR.Text = "Contar letras \"R\"";
            this.btnQuanidadeR.UseVisualStyleBackColor = true;
            this.btnQuanidadeR.Click += new System.EventHandler(this.btnQuanidadeR_Click);
            // 
            // btnEspaçosEmBranco
            // 
            this.btnEspaçosEmBranco.Location = new System.Drawing.Point(106, 214);
            this.btnEspaçosEmBranco.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEspaçosEmBranco.Name = "btnEspaçosEmBranco";
            this.btnEspaçosEmBranco.Size = new System.Drawing.Size(123, 89);
            this.btnEspaçosEmBranco.TabIndex = 7;
            this.btnEspaçosEmBranco.Text = "Contar espaços em branco";
            this.btnEspaçosEmBranco.UseVisualStyleBackColor = true;
            this.btnEspaçosEmBranco.Click += new System.EventHandler(this.btnEspaçosEmBranco_Click);
            // 
            // rchtTxt
            // 
            this.rchtTxt.Location = new System.Drawing.Point(106, 43);
            this.rchtTxt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rchtTxt.Name = "rchtTxt";
            this.rchtTxt.Size = new System.Drawing.Size(421, 142);
            this.rchtTxt.TabIndex = 6;
            this.rchtTxt.Text = "";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 347);
            this.Controls.Add(this.btnParDeLetras);
            this.Controls.Add(this.btnQuanidadeR);
            this.Controls.Add(this.btnEspaçosEmBranco);
            this.Controls.Add(this.rchtTxt);
            this.Name = "frmExercicio1";
            this.Text = "Exercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnParDeLetras;
        private System.Windows.Forms.Button btnQuanidadeR;
        private System.Windows.Forms.Button btnEspaçosEmBranco;
        private System.Windows.Forms.RichTextBox rchtTxt;
    }
}