﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7._2
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

       

        private void btnCalcSalarioBruto_Click(object sender, EventArgs e)
        {
            {
                //A forma de cálculo do salário bruto dos funcionários de uma empresa é a
                //seguinte:
                //salário bruto = A + Ax(0, 05xB + 0, 1xC + 0, 1xD) + Total de gratificações
                //Onde:
                //A = salário de acordo com o cargo(plano de carreira)
                //B = Produção >= 100->se sim B = 1 caso contrário B = 0
                //C = Produção >= 120->se sim C = 1 caso contrário C = 0
                //D = Produção >= 150->se sim D = 1 caso contrário D = 0
                //Restrição: O maior Salário Bruto a ser pago é 7.000,00.
                //Valor acima de 7.000,00 só
                //poderá ser pago a funcionários com Produção>= 150
                //e que tenham gratificação.
                //Fazer um programa que Solicite: Nome, Cargo, Numero de
                //Inscrição, Produção,
                //Salário e Gratificação.Calcule o Salário Bruto.
                //Usando na lógica a instrução IF.


                string nome = txtNome.Text;
                string cargo = txtCargo.Text;
                double gratificacao = 0;
                double producao = 0;
                double salario = 0;
                double salarioBruto = 0;
                double a = 0;
                double b = 0;
                double c = 0;
                double d = 0;


                if ((txtNome.Text == "") || (txtNome.Text.Length < 5) ||
                    (txtGratificacao.Text == "") || (txtCargo.Text == "") ||
                    (txtInscricao.Text == "") || (txtProducao.Text == "") ||
                    (txtSalario.Text == ""))
                    MessageBox.Show("Nome inválido!");

                else if (double.TryParse(txtSalario.Text, out salario) &&
                    (double.TryParse(txtProducao.Text, out producao) &&
                    (double.TryParse(txtGratificacao.Text, out gratificacao))))
                {

                    if (producao < 100)
                        a = salario * 1;
                    else if (producao >= 100)
                        b = salario * 0.5;
                    else if (producao >= 120)
                        c = salario + (salario * 1);
                    else if (producao >= 150)
                        d = salario + (salario * 1);
                    else
                    {
                        MessageBox.Show("Salário bruto inválido");
                    }
                }
                //salário bruto = A + Ax(0, 05xB + 0, 1xC + 0, 1xD)
                //+ Total de gratificações
                salarioBruto = salario + a * (0.5 * b + 0.1 * c + 0.1 * d) + gratificacao;

                MessageBox.Show(Convert.ToString(salarioBruto));
            }
        }
    } }
