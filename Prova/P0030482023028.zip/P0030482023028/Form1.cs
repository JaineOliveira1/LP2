﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482023028
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            // o último dígito do meu RA é 8
            double[,] Valores = new double[8, 4];
            double[] TotalDoMes = new double[8];
            string valor;
            double totaldeMeses = 0;

            for (int x = 0; x < 5; x++)
            {
                for (int y = 0; y < 4; y++)
                {
                    valor = Interaction.InputBox("Insira o valor na semana " + (y + 1) + " Do Mês: " + (x + 1), "Entrada de dados");
                    if (valor == "")
                    {
                        MessageBox.Show("Este campo está vazio. Por favor, preencha corretamente");
                        y--;
                    }
                    else if (double.TryParse(valor, out Valores[x, y]))
                    {
                        double.TryParse(valor, out Valores[x, y]);
                    }
                    else
                    {
                        MessageBox.Show("Esse campo aceita apenas números!");
                        y--;
                    }
                }
            }

            for (int x = 0; x < 8; x++)
            {
                for (int y = 0; y < 4; y++)
                {
                    TotalDoMes[x] = TotalDoMes[x] + Valores[x, y];
                }
                totaldeMeses = totaldeMeses + TotalDoMes[x];
            }
            for (int x = 0; x < 8; x++)
            {
                for (int y = 0; y < 4; y++)
                {
                    lstbxResultados.Items.Add("Total do Mês: " + (x + 1) + " Semana: " + (y + 1) + ": R$" + Valores[x, y].ToString("N2"));
                }
                lstbxResultados.Items.Add(">>  Total Mês: R$" + TotalDoMes[x].ToString("N2"));
                lstbxResultados.Items.Add("...............................");
            }
            lstbxResultados.Items.Add("Total Geral: R$" + totaldeMeses.ToString("N2"));
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

