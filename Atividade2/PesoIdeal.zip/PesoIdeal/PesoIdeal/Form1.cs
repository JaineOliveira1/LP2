﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PesoIdeal
{
    public partial class Form1 : Form
    {
        double pesoatual, pesoideal, altura;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txt1.Text = " ";
            txt2.Text = " ";
            txt3.Text = " ";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                pesoideal = (62.1 * altura) - 44.7;
            else
                pesoideal = (72.7 * altura) - 58;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out pesoatual) &&
               double.TryParse(txt2.Text, out altura)) // se conseguiu converter, numeros sao validos
            {
                if (radioButton1.Checked) // testa se é mulher
                    pesoideal = (62.1 * altura) - 44.7; // formula para mulher
                else
                    pesoideal = (72.7 * altura) - 58; // formula para homem



                pesoideal = Math.Round(pesoideal, 2); // arredondando a conta senao
                // nunca peso ideal = peso atual
                txt3.Text = pesoideal.ToString();



                if (pesoatual > pesoideal)
                    MessageBox.Show("Você está acima do seu peso ideal!!!");
                if (pesoatual < pesoideal)
                    MessageBox.Show("Você está abaixo do seu peso ideal!!!");
                else // se ja passou pelo 2 testes nao precisa fazer outro if, so else
                    // 2 situacoes = 1 if e 3 situacoes = 2 ifs
                    MessageBox.Show("Muito bem! Você está com o peso ideal!!!");
            }
            else
                MessageBox.Show("Dados invalidos");
        }

        private void txt3_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
