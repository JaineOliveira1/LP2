﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PesoIdeal
{
    public partial class Form1 : Form
    {
        double pesoatual, pesoideal, altura, sexof, sexom, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txt1.Text = " ";
            txt2.Text = " ";
            txt3.Text = " ";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                pesoideal = (62.1 * altura) - 44.7;
            else
                pesoideal = (72.7 * altura) - 58;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                resultado = Math.Round(resultado, 2);
            if (pesoatual > resultado)
                MessageBox.Show("Você está acima do seu peso ideal!!!");
            if (pesoatual < resultado)
                MessageBox.Show("Você está abaixo do seu peso ideal!!!");
            else (pesoatual = resultado);
                MessageBox.Show("Muito bem! Você está com o peso ideal!!!");
        }
    }
}
