﻿namespace PMetodos
{
    partial class v
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnCaracteresNumericos = new System.Windows.Forms.Button();
            this.btnCaractereEmBranco = new System.Windows.Forms.Button();
            this.btnCaracteresAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtTexto
            // 
            this.rchtxtTexto.Location = new System.Drawing.Point(42, 12);
            this.rchtxtTexto.Name = "rchtxtTexto";
            this.rchtxtTexto.Size = new System.Drawing.Size(414, 110);
            this.rchtxtTexto.TabIndex = 0;
            this.rchtxtTexto.Text = "";
            // 
            // btnCaracteresNumericos
            // 
            this.btnCaracteresNumericos.Location = new System.Drawing.Point(42, 172);
            this.btnCaracteresNumericos.Name = "btnCaracteresNumericos";
            this.btnCaracteresNumericos.Size = new System.Drawing.Size(77, 71);
            this.btnCaracteresNumericos.TabIndex = 1;
            this.btnCaracteresNumericos.Text = "Caracteres numéricos";
            this.btnCaracteresNumericos.UseVisualStyleBackColor = true;
            this.btnCaracteresNumericos.Click += new System.EventHandler(this.btnCaracteresNumericos_Click);
            // 
            // btnCaractereEmBranco
            // 
            this.btnCaractereEmBranco.Location = new System.Drawing.Point(210, 172);
            this.btnCaractereEmBranco.Name = "btnCaractereEmBranco";
            this.btnCaractereEmBranco.Size = new System.Drawing.Size(78, 71);
            this.btnCaractereEmBranco.TabIndex = 2;
            this.btnCaractereEmBranco.Text = "Localizar caractere em branco";
            this.btnCaractereEmBranco.UseVisualStyleBackColor = true;
            // 
            // btnCaracteresAlfabeticos
            // 
            this.btnCaracteresAlfabeticos.Location = new System.Drawing.Point(381, 172);
            this.btnCaracteresAlfabeticos.Name = "btnCaracteresAlfabeticos";
            this.btnCaracteresAlfabeticos.Size = new System.Drawing.Size(75, 71);
            this.btnCaracteresAlfabeticos.TabIndex = 3;
            this.btnCaracteresAlfabeticos.Text = "Caracteres alfabéticos";
            this.btnCaracteresAlfabeticos.UseVisualStyleBackColor = true;
            // 
            // v
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 322);
            this.Controls.Add(this.btnCaracteresAlfabeticos);
            this.Controls.Add(this.btnCaractereEmBranco);
            this.Controls.Add(this.btnCaracteresNumericos);
            this.Controls.Add(this.rchtxtTexto);
            this.Name = "v";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtTexto;
        private System.Windows.Forms.Button btnCaracteresNumericos;
        private System.Windows.Forms.Button btnCaractereEmBranco;
        private System.Windows.Forms.Button btnCaracteresAlfabeticos;
    }
}