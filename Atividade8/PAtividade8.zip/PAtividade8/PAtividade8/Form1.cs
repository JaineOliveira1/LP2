﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            //string saida="";

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Entre com o número da posição:" + (i + 1).ToString(),
                    "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }
            auxiliar = "";

            for (var i = vetor.Length - 1; i >= 0; i--)
                auxiliar += "\n" + vetor[i];


            MessageBox.Show(auxiliar);


            //else 
            //saida = vetor[i] + "\n" + saída;
            //message.box.show(saida);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            //string saida="";

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Entre com o número da posição:" + (i + 1).ToString(),
                    "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }
            auxiliar = "";

            for (var i = vetor.Length - 1; i >= 0; i--)
                auxiliar += "\n" + vetor[i];

            char[] inverso = auxiliar.ToCharArray();
            Array.Reverse(inverso);
            foreach (char c in inverso)
            {
                auxiliar = auxiliar + c.ToString();
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            /*TENTATIVA QUE NÃO DEU CERTO ;(
             * 
             * int[,] vetor = new int[2, 10];
            string auxiliar = "";
           
            for (var i = 0; i < vetor.Length; i++)
            for (var j = 0;j < vetor.Length;j++)
            
                {
                    auxiliar = Interaction.InputBox("Digite a quantidade:" + (i + 1).ToString(),"Entrada de dados");
                {
                    auxiliar = Interaction.InputBox("Digite a quantidade:" + (i + 1).ToString(), "Entrada de dados");
                    }
                    {
                        if (!int.TryParse(auxiliar, out vetor[i,j]))

                        {
                            MessageBox.Show("Número inválido");
                            i--;
                        
                        }
                    }
                }*/
            
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio",
                                "Denise", "Junior","Leonardo",
                                 "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());

            // RESPOSTA: 46
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            string[] Alunos = new string[10];

            Alunos[0] = "Ana";
            Alunos[1] = "André";
            Alunos[2] = "Débora";
            Alunos[3] = "Fátima";
            Alunos[4] = "João";
            Alunos[5] = "Janete";
            Alunos[6] = "Otávio";
            Alunos[7] = "Marcelo";
            Alunos[8] = "Pedro";
            Alunos[9] = "Thais";

            Array.Clear(Alunos, 6,1);
            foreach (var x in Alunos)
            {
                MessageBox.Show(x);
            }

        }

        private void btnExercício6_Click(object sender, EventArgs e)
        {
            //6) Crie uma matriz para guardar as 3 notas (nota1, nota2, nota3) de uma
            //disciplina de uma turma de 20 alunos.Considere os alunos como as
            //linhas e as notas como as colunas.Receba os dados via InputBox.
            //Calcule e mostre a média de aluno(média = (nota1 + nota2 + nota3) / 3 de
            //maneira que a saída fique como no exemplo:
            // 1: média: 8, 5
            //Aluno 2: média 10, 0
            //Aluno 3: média 5, 0
            //E assim por diante.

            /* TENTATIVA QUE NÃO DEU CERTO 2 ;(
             * 
             * 

            int[,] vetor = new int[5,3];
            int x = 0;
            int y = 0;
            double media = 0;
            string valor = "";

            for (x = 0; x < vetor.Length; x++)
            {
                for (y = 0; y < 3; y++) ;
            }    
            {
                valor = Interaction.InputBox("Entre com a nota da disciplina:" + (y + 1).ToString(),
                "Entrada de dados");
                valor = Interaction.InputBox("Entre com aluno" + (x + 1).ToString(), "Entrada de dados");


                if (valor == "")
               
                if (int.TryParse(valor, out vetor[x,y]))
                {
                    if (vetor[x,y] >= 0 && vetor[x,y] <= 10)
                        media += vetor[x,y];
                    else
                    {
                        MessageBox.Show("Média deve estar em 0 e 10!");
                        x--;
                    }
                }
                else
                {
                    MessageBox.Show("Número Inválido!");
                    x--;
                }
            }
            MessageBox.Show("A média entre as cinco disciplinas é: " + (media /
            5).ToString("N2"));
        }*/
    }
}
        
                    
