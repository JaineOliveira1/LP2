﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculoSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void lblnome_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblSalarioLiquido_Click(object sender, EventArgs e)
        {

        }

        private void btnVerificarDesconto_Click(object sender, EventArgs e)
        {
            lblMensagem.Visible = true;
            /** 
                Aliquota INSS para Salário Bruto:
                Até 800.47 - 7.65%
                De 800.48 a 1050 - 8.65%
                De 1050.01 a 1400.77 – 9.00%
                De 1400.78 a 2801.56 – 11.00%
                >2801.56 -> Desconto = 308.17 (teto)
             **/

            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioFamilia = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double numeroFilhos = 0;
            double NumeroFilhos = 0;

            if ((txtNomeFuncionario.Text == "") || (txtNomeFuncionario.Text.Length < 5))
                MessageBox.Show("Nome inválido!");

            else if (double.TryParse(mskbxSalarioBruto.Text, out salarioBruto) &&
                    (double.TryParse(cbxNumeroFilhos.Text, out NumeroFilhos)))

            {
                //calculo do INSS

                if (salarioBruto <= 800.47)
                {
                    txtAliquotaINSS.Text = "7.65%";
                    descontoINSS = 0.0765 * salarioBruto;
                }
                else if (salarioBruto <= 1050)
                {
                    txtAliquotaINSS.Text = "8.65%";
                    descontoINSS = 0.0865 * salarioBruto;
                }
                else if (salarioBruto <= 1400.77)
                {
                    txtAliquotaINSS.Text = "9.00%";
                    descontoINSS = 0.0900 * salarioBruto;
                }
                else if (salarioBruto <= 2801.56)
                {
                    txtAliquotaINSS.Text = "11.00%";
                    descontoINSS = 0.11 * salarioBruto;
                }
                else if (salarioBruto > 2801.56)
                {
                    txtAliquotaINSS.Text = "Desconto de R$308,17";
                    descontoINSS = 308.17;
                }
                else
                MessageBox.Show("Salário Bruto Inválido!");


                txtDescontoINSS.Text = descontoINSS.ToString("N2");
                /**
                    calculo IRPF
                    Alíquota IRPF para Salário Bruto:
                    Até 1257.12 - isento
                    De 1257.13 a 2512.08 – 15.00%
                    > 2512.08 - 27.5%
                 **/

                if (salarioBruto <= 2801.56)
                {
                    txtAliquotaIRPF.Text = "Isento";
                    descontoIRPF = 0;
                }
                else if (salarioBruto <= 2512.08)
                {
                    txtAliquotaIRPF.Text = "15%";
                    descontoIRPF = 0.15 * salarioBruto;
                }
                else if (salarioBruto > 2512.08)
                {
                    txtAliquotaIRPF.Text = "27.5%";
                    descontoIRPF = 0.275 * salarioBruto;
                }

                txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
                /** 
                    Calculo salario familia
                    Salário Família para Salário Bruto:
                    Até 435.52 - 22.33 por filho
                    De 435.53 a 654.61 - 15.74 por filho
                    >654.61 – 0 **/
                if (salarioBruto <= 435.52)
                {
                    txtSalarioFamilia.Text = "R$22.33 por filho";
                    salarioFamilia = (22.33 * numeroFilhos) + salarioBruto;
                }
                else if (salarioBruto <= 654.61)
                {
                    txtSalarioFamilia.Text = "R$15.74 por filho ";
                    salarioFamilia = (15.74 * numeroFilhos) + salarioBruto;
                }
                else if (salarioBruto > 654.61)
                {
                    txtSalarioFamilia.Text = "0";
                    salarioFamilia = 0;
                }
                txtSalarioFamilia.Text = salarioFamilia.ToString("N2");            
            
                salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                txtSalarioLiquido.Text = salarioLiquido.ToString("N2");


                // montar a mensagem no label
                {
                
                   lblMensagem.Text = "\nOs descontos do salário";

                    if (rbtnFeminino.Checked)
                        lblMensagem.Text = lblMensagem.Text + " da Sra.\n" + txtNomeFuncionario.Text;
                    else
                        lblMensagem.Text = lblMensagem.Text + " do Sr.\n" + txtNomeFuncionario.Text;

                    lblMensagem.Text = lblMensagem + " que é";

                    if (ckbxCasado.Checked)
                        lblMensagem.Text = lblMensagem.Text + " Casado(a)";
                    else
                        lblMensagem.Text = lblMensagem.Text + " Solteiro(a)\n";

                    lblMensagem.Text = lblMensagem.Text + " e que tem";

                    lblMensagem.Text = lblMensagem.Text + NumeroFilhos + " filho(s)";

                    lblMensagem.Text = lblMensagem.Text + " são:\n";
                }
            }

        }


        private void ckbxCasado_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lblAliquotaINSS_Click(object sender, EventArgs e)
        {

        }

        private void lblAliquotaIRPF_Click(object sender, EventArgs e)
        {

        }

        private void lblMensagem_Click(object sender, EventArgs e)
        {

        }
    }
}