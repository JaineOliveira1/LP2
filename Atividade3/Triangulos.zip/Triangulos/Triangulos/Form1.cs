﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulos
{
    public partial class Form1 : Form
    {
        double a, b, c;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txt1.Text = " ";
            txt2.Text = " ";
            txt3.Text = " ";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out a) &&
                    double.TryParse(txt2.Text, out b) &&
                    double.TryParse(txt3.Text, out c))
            { // testar se está dentro da regra
                if ((b - c < a && a < b + c) && (a - c < b && b < a + c) && (a - b < c && c < a + b))
                {
                    if (a == b && b == c)
                        MessageBox.Show("Triângulo Equilátero");
                    else if (a == b || b == c || a == c)
                        MessageBox.Show("Triângulo Isósceles");
                    else if (a != b && b != c)
                        MessageBox.Show("Triângulo Escaleno");
                }



                else
                    MessageBox.Show("Não é triângulo");
            }
            else



                MessageBox.Show("Dados inválidos");

        }
    }
}
